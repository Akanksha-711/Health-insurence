"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ExternalLink,
  CheckCircle2,
  Building2,
  Users,
  Clock,
  IndianRupee
} from "lucide-react";

const CompareTable = ({ plans }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (!plans || plans.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="py-12 text-center">
          <p className="text-muted-foreground">Select 2-3 plans to compare</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[800px]">
        <div
          className="grid gap-6"
          style={{
            gridTemplateColumns: `repeat(${plans.length}, minmax(300px, 1fr))`
          }}
        >
          {plans.map((plan) => (
            <Card
              key={plan.id}
              className="border-2 border-primary/20 shadow-medium"
            >
              <CardHeader className="bg-gradient-to-br from-primary/10 to-transparent pb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Building2 className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium text-muted-foreground">
                    {plan.company}
                  </span>
                </div>
                <CardTitle className="text-xl">{plan.planName}</CardTitle>
              </CardHeader>

              <CardContent className="space-y-6 pt-6">
                {/* Coverage, Premium, Waiting Period, Network Hospitals */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50">
                    <IndianRupee className="h-5 w-5 text-primary" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Coverage</p>
                      <p className="text-xl font-bold text-primary">
                        {formatCurrency(plan.coverage)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 p-3 rounded-lg bg-accent/10">
                    <IndianRupee className="h-5 w-5 text-accent" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Premium</p>
                      <p className="text-lg font-semibold text-foreground">
                        {formatCurrency(plan.monthlyPremium)}/mo
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatCurrency(plan.premium)}/year
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
                    <Clock className="h-5 w-5 text-accent" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">
                        Waiting Period
                      </p>
                      <p className="text-sm font-medium text-foreground">
                        {plan.waitingPeriod}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
                    <Users className="h-5 w-5 text-primary" />
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">
                        Network Hospitals
                      </p>
                      <p className="text-sm font-medium text-foreground">
                        {plan.networkHospitals.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Benefits */}
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-foreground">
                    Benefits
                  </h4>
                  <div className="space-y-2">
                    {plan.benefits.map((benefit, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-foreground/80">
                          {benefit}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Call to action button */}
                <Button
                  className="w-full bg-gradient-to-r from-accent to-accent/90 hover:from-accent/90 hover:to-accent text-accent-foreground font-semibold shadow-soft hover:shadow-medium transition-all duration-300"
                  onClick={() => window.open(plan.applyLink, "_blank")}
                >
                  Apply Now
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CompareTable;
