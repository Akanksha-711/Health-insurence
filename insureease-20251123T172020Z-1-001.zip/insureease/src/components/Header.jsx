"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Shield } from "lucide-react";

const Header = () => {
  const pathname = usePathname();

  const isActive = (path) => pathname === path;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/80 backdrop-blur-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="p-2 rounded-xl bg-linear-to-br from-primary to-primary/80 shadow-soft group-hover:shadow-medium transition-all duration-300">
              <Shield className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-linear-to-br from-primary to-primary/70 bg-clip-text text-transparent">
                InsureEase
              </h1>
              <p className="text-xs text-muted-foreground">
                Smart Insurance Comparison
              </p>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link
              href="/"
              className={`text-sm font-medium transition-colors ${
                isActive("/") 
                  ? "text-primary font-semibold" 
                  : "text-foreground/70 hover:text-primary"
              }`}
            >
              Browse Plans
            </Link>

            <Link
              href="/compare"
              className={`text-sm font-medium transition-colors ${
                isActive("/compare")
                  ? "text-primary font-semibold"
                  : "text-foreground/70 hover:text-primary"
              }`}
            >
              Compare
            </Link>

            <Link
              href="/admin"
              className={`text-sm font-medium transition-colors ${
                isActive("/admin")
                  ? "text-primary font-semibold"
                  : "text-foreground/70 hover:text-primary"
              }`}
            >
              Admin
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
