"use client";

import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  CheckCircle2,
  ExternalLink,
  Building2,
  Users,
  Clock
} from "lucide-react";

const PlanCard = ({ plan, isSelected, onToggleSelect }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <Card className="group hover:shadow-strong transition-all duration-300 border-border hover:border-primary/30 relative overflow-hidden">
      {/* Hover overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      <CardHeader className="relative">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            {/* Company */}
            <div className="flex items-center gap-2 mb-2">
              <Building2 className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-muted-foreground">
                {plan.company}
              </span>
            </div>

            {/* Plan Name */}
            <h3 className="text-xl font-bold text-foreground mb-2">
              {plan.planName}
            </h3>
          </div>

          {/* Selection checkbox */}
          <Checkbox
            checked={isSelected}
            onCheckedChange={() => onToggleSelect(plan.id)}
            className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
          />
        </div>

        {/* Coverage */}
        <div className="flex items-baseline gap-2 mt-3">
          <span className="text-3xl font-bold text-primary">
            {formatCurrency(plan.coverage)}
          </span>
          <span className="text-sm text-muted-foreground">coverage</span>
        </div>

        {/* Premium */}
        <div className="flex items-baseline gap-1 mt-2">
          <span className="text-2xl font-semibold text-foreground">
            {formatCurrency(plan.monthlyPremium)}
          </span>
          <span className="text-sm text-muted-foreground">/month</span>
          <span className="text-xs text-muted-foreground ml-1">
            ({formatCurrency(plan.premium)}/year)
          </span>
        </div>
      </CardHeader>

      <CardContent className="relative space-y-4">
        {/* Hospital & Waiting Period */}
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1.5">
            <Users className="h-4 w-4 text-primary" />
            <span className="text-muted-foreground">
              {plan.networkHospitals.toLocaleString()} hospitals
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <Clock className="h-4 w-4 text-accent" />
            <span className="text-muted-foreground">{plan.waitingPeriod}</span>
          </div>
        </div>

        {/* Benefits */}
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-foreground">Key Benefits:</h4>

          <div className="space-y-1.5">
            {plan.benefits.slice(0, 4).map((benefit, index) => (
              <div key={index} className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                <span className="text-sm text-foreground/80">{benefit}</span>
              </div>
            ))}

            {plan.benefits.length > 4 && (
              <Badge variant="secondary" className="text-xs">
                +{plan.benefits.length - 4} more benefits
              </Badge>
            )}
          </div>
        </div>
      </CardContent>

      <CardFooter className="relative">
        <Button
          className="w-full bg-gradient-to-r from-accent to-accent/90 hover:from-accent/90 hover:to-accent text-accent-foreground font-semibold shadow-soft hover:shadow-medium transition-all duration-300"
          onClick={() => window.open(plan.applyLink, "_blank")}
        >
          Apply Now
          <ExternalLink className="ml-2 h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PlanCard;