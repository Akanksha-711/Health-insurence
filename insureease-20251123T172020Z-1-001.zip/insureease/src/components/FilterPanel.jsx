"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { SlidersHorizontal } from "lucide-react";

const companies = [
  "Star Health",
  "Aditya Birla",
  "Max Bupa",
  "HDFC Ergo",
  "Care Health",
  "Niva Bupa",
  "ICICI Lombard",
  "Bajaj Allianz",
];

const FilterPanel = ({
  selectedCoverage,
  onCoverageChange,
  selectedCompanies,
  onCompanyToggle,
  premiumRange,
  onPremiumRangeChange,
}) => {
  return (
    <Card className="sticky top-24 shadow-soft border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <SlidersHorizontal className="h-5 w-5 text-primary" />
          Filters
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Coverage Amount */}
        <div className="space-y-3">
          <Label className="text-sm font-semibold text-foreground">Coverage Amount</Label>

          <RadioGroup value={selectedCoverage} onValueChange={onCoverageChange}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="all" id="all" />
              <Label htmlFor="all" className="text-sm cursor-pointer">
                All Plans
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <RadioGroupItem value="200000" id="2l" />
              <Label htmlFor="2l" className="text-sm cursor-pointer">
                Above ₹2L
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <RadioGroupItem value="500000" id="5l" />
              <Label htmlFor="5l" className="text-sm cursor-pointer">
                Above ₹5L
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <RadioGroupItem value="1000000" id="10l" />
              <Label htmlFor="10l" className="text-sm cursor-pointer">
                Above ₹10L
              </Label>
            </div>
          </RadioGroup>
        </div>

        {/* Monthly Premium Slider */}
        <div className="space-y-3">
          <Label className="text-sm font-semibold text-foreground">
            Monthly Premium: ₹{premiumRange[0]} - ₹{premiumRange[1]}
          </Label>

          <Slider
            min={0}
            max={2000}
            step={50}
            value={premiumRange}
            onValueChange={onPremiumRangeChange}
            className="w-full"
          />
        </div>

        {/* Insurance Companies */}
        <div className="space-y-3">
          <Label className="text-sm font-semibold text-foreground">Insurance Companies</Label>

          <div className="space-y-2 max-h-64 overflow-y-auto">
            {companies.map((company) => (
              <div key={company} className="flex items-center space-x-2">
                <Checkbox
                  id={company}
                  checked={selectedCompanies.includes(company)}
                  onCheckedChange={() => onCompanyToggle(company)}
                  className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                />

                <Label
                  htmlFor={company}
                  className="text-sm cursor-pointer hover:text-primary transition-colors"
                >
                  {company}
                </Label>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterPanel;
