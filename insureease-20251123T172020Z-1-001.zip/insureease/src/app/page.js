"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import PlanCard from "@/components/PlanCard";
import FilterPanel from "@/components/FilterPanel";
import { Button } from "@/components/ui/button";
import { mockPlans } from "@/data/mockPlans";
import { ArrowRight, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Home = () => {
  const router = useRouter();
  const { toast } = useToast();
  const [selectedPlans, setSelectedPlans] = useState([]);
  const [selectedCoverage, setSelectedCoverage] = useState("all");
  const [selectedCompanies, setSelectedCompanies] = useState([]);
  const [premiumRange, setPremiumRange] = useState([0, 2000]);

  const filteredPlans = useMemo(() => {
    return mockPlans.filter((plan) => {
      if (selectedCoverage !== "all" && plan.coverage < parseInt(selectedCoverage)) {
        return false;
      }
      if (selectedCompanies.length > 0 && !selectedCompanies.includes(plan.company)) {
        return false;
      }
      if (plan.monthlyPremium < premiumRange[0] || plan.monthlyPremium > premiumRange[1]) {
        return false;
      }
      return true;
    });
  }, [selectedCoverage, selectedCompanies, premiumRange]);

  const handleToggleSelect = (planId) => {
    setSelectedPlans((prev) => {
      if (prev.includes(planId)) return prev.filter((id) => id !== planId);
      if (prev.length >= 3) {
        toast({
          title: "Maximum 3 plans",
          description: "You can compare up to 3 plans at a time",
          variant: "destructive",
        });
        return prev;
      }
      return [...prev, planId];
    });
  };

  const handleCompare = () => {
    if (selectedPlans.length < 2) {
      toast({
        title: "Select at least 2 plans",
        description: "Please select at least 2 plans to compare",
        variant: "destructive",
      });
      return;
    }
    router.push(`/compare?selectedPlanIds=${selectedPlans.join(",")}`);
  };

  const handleCompanyToggle = (company) => {
    setSelectedCompanies((prev) =>
      prev.includes(company) ? prev.filter((c) => c !== company) : [...prev, company]
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative py-16 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-linear-to-r from-primary/10 via-transparent to-accent/5" />
        <div className="container mx-auto relative">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            {/* <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-primary/20">
              <Shield className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground">Trusted by thousands</span>
            </div> */}
            <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight">
              Find Your Perfect{" "}
              <span className="bg-linear-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                Health Insurance
              </span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Compare top health insurance plans from leading providers. Find the best coverage for
              your family at competitive prices.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Filters */}
            <aside className="lg:col-span-1">
              <FilterPanel
                selectedCoverage={selectedCoverage}
                onCoverageChange={setSelectedCoverage}
                selectedCompanies={selectedCompanies}
                onCompanyToggle={handleCompanyToggle}
                premiumRange={premiumRange}
                onPremiumRangeChange={setPremiumRange}
              />
            </aside>

            {/* Plans Grid */}
            <main className="lg:col-span-3">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-foreground">Available Plans</h2>
                  <p className="text-sm text-muted-foreground">
                    {filteredPlans.length} plans found
                  </p>
                </div>
                {selectedPlans.length > 0 && (
                  <Button
                    onClick={handleCompare}
                    className="bg-linear-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary text-primary-foreground font-semibold shadow-soft hover:shadow-medium transition-all duration-300"
                  >
                    Compare {selectedPlans.length} Plans
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredPlans.map((plan) => (
                  <PlanCard
                    key={plan.id}
                    plan={plan}
                    isSelected={selectedPlans.includes(plan.id)}
                    onToggleSelect={handleToggleSelect}
                  />
                ))}
              </div>

              {filteredPlans.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-lg text-muted-foreground">
                    No plans found matching your filters. Try adjusting your criteria.
                  </p>
                </div>
              )}
            </main>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
