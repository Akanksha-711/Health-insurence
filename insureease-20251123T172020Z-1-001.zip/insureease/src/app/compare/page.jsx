"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import CompareTable from "@/components/CompareTable";
import { Button } from "@/components/ui/button";
import { mockPlans } from "@/data/mockPlans";
import { ArrowLeft } from "lucide-react";

const Compare = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [selectedPlans, setSelectedPlans] = useState([]);

  useEffect(() => {
    // Get selectedPlanIds from query string
    const idsParam = searchParams.get("selectedPlanIds");
    if (idsParam) {
      const selectedPlanIds = idsParam.split(",");
      const plans = mockPlans.filter((plan) =>
        selectedPlanIds.includes(plan.id)
      );
      setSelectedPlans(plans);
    }
  }, [searchParams]);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <section className="py-8 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <Button
              variant="ghost"
              onClick={() => router.push("/")}
              className="mb-4 hover:bg-secondary"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Plans
            </Button>

            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
              Compare Insurance Plans
            </h1>
            <p className="text-muted-foreground">
              Side-by-side comparison of selected health insurance plans
            </p>
          </div>

          <CompareTable plans={selectedPlans} />
        </div>
      </section>
    </div>
  );
};

export default Compare;