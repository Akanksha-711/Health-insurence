export const mockPlans = [
  {
    id: "1",
    company: "Star Health",
    planName: "Family Health Optima",
    coverage: 500000,
    premium: 4500,
    monthlyPremium: 425,
    benefits: [
      "Cashless Claims",
      "ICU Coverage",
      "Maternity Benefits",
      "Pre & Post Hospitalization",
      "No Room Rent Limit"
    ],
    waitingPeriod: "2 Years",
    networkHospitals: 6000,
    applyLink: "https://www.starhealth.in"
  },
  {
    id: "2",
    company: "Aditya Birla",
    planName: "Active Health Platinum",
    coverage: 1000000,
    premium: 7800,
    monthlyPremium: 725,
    benefits: [
      "Worldwide Coverage",
      "OPD Benefits",
      "Wellness Programs",
      "Annual Health Checkup",
      "Ambulance Cover"
    ],
    waitingPeriod: "3 Years",
    networkHospitals: 5500,
    applyLink: "https://www.adityabirlacapital.com"
  },
  {
    id: "3",
    company: "Max Bupa",
    planName: "Health Companion",
    coverage: 300000,
    premium: 3200,
    monthlyPremium: 299,
    benefits: [
      "Cashless Network",
      "Day Care Procedures",
      "Pre-existing Diseases",
      "Mental Health Coverage",
      "No Claim Bonus"
    ],
    waitingPeriod: "1 Year",
    networkHospitals: 4000,
    applyLink: "https://www.maxbupa.com"
  },
  {
    id: "4",
    company: "HDFC Ergo",
    planName: "My Health Suraksha",
    coverage: 1500000,
    premium: 9500,
    monthlyPremium: 875,
    benefits: [
      "Zero Waiting Period Option",
      "Unlimited Restoration",
      "Global Coverage",
      "Organ Donor Coverage",
      "Home Healthcare"
    ],
    waitingPeriod: "2 Years",
    networkHospitals: 7200,
    applyLink: "https://www.hdfcergo.com"
  },
  {
    id: "5",
    company: "Care Health",
    planName: "Care Advantage",
    coverage: 750000,
    premium: 5900,
    monthlyPremium: 549,
    benefits: [
      "Modern Treatment",
      "Second Opinion",
      "Consumables Coverage",
      "Airport Transfer",
      "Recovery Benefit"
    ],
    waitingPeriod: "2 Years",
    networkHospitals: 8500,
    applyLink: "https://www.careinsurance.com"
  },
  {
    id: "6",
    company: "Niva Bupa",
    planName: "Reassure 2.0",
    coverage: 2000000,
    premium: 12500,
    monthlyPremium: 1150,
    benefits: [
      "Auto-renewal",
      "Preventive Care",
      "Teleconsultation",
      "AYUSH Treatment",
      "Domiciliary Hospitalization"
    ],
    waitingPeriod: "3 Years",
    networkHospitals: 9000,
    applyLink: "https://www.nivabupa.com"
  },
  {
    id: "7",
    company: "ICICI Lombard",
    planName: "Health AdvantEdge",
    coverage: 500000,
    premium: 4200,
    monthlyPremium: 395,
    benefits: [
      "E-Opinion",
      "Vaccination Cover",
      "Diagnostic Cover",
      "Consumables Included",
      "Mental Wellness"
    ],
    waitingPeriod: "2 Years",
    networkHospitals: 6800,
    applyLink: "https://www.icicilombard.com"
  },
  {
    id: "8",
    company: "Bajaj Allianz",
    planName: "Health Guard",
    coverage: 1000000,
    premium: 6800,
    monthlyPremium: 629,
    benefits: [
      "Day Care",
      "Organ Donation",
      "Road Ambulance",
      "Critical Illness",
      "Personal Accident"
    ],
    waitingPeriod: "2 Years",
    networkHospitals: 7500,
    applyLink: "https://www.bajajallianz.com"
  }
];
