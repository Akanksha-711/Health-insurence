(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3d6cfa8e._.js",
  "static/chunks/src_6b6220db._.js"
],
    source: "dynamic"
});
