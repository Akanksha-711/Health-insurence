(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_18828bd1._.js",
  "static/chunks/src_65c14d22._.js"
],
    source: "dynamic"
});
